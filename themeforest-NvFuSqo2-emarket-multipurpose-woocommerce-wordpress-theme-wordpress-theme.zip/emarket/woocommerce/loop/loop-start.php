<?php
/**
 * Product Loop Start
 *
 * @author 		WooThemes
 * @package 	WooCommerce/Templates
 * @version     3.3.0
 */
?>
<ul  class="products products-loop row <?php echo emarket_options()->getCpanelValue( 'product_layout' ); ?> clearfix" id="product_listing">